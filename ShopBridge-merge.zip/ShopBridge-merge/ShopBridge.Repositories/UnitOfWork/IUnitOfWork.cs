﻿using ShopBridge.Models.EFModels;
using ShopBridge.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.Repositories.UnitOfWork
{
    public interface IUnitOfWork
    {
        GenericRepository<Product> ProductRepository { get; set; }
        GenericRepository<ProductCategory> ProductCategoryRepository { get; set; }
        int Save();
    }
}
