﻿using ShopBridge.Models;
using ShopBridge.Models.EFModels;
using ShopBridge.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.Repositories.UnitOfWork
{
    public  class UnitOfWork :IUnitOfWork,IDisposable
    {
        private readonly Models.EFModels.ShopBridgeContext _context = null;

        private GenericRepository<Product> _productRepository;
        private GenericRepository<ProductCategory> _productCategoryRepository;

        public UnitOfWork(Models.EFModels.ShopBridgeContext context)
        {
            _context = context;
        }

        public GenericRepository<Product> ProductRepository { get { return this._productRepository ?? (this._productRepository = new GenericRepository<Product>(this._context)); } set { this._productRepository = value; } }
        public GenericRepository<ProductCategory> ProductCategoryRepository { get { return this._productCategoryRepository ?? (this._productCategoryRepository = new GenericRepository<ProductCategory>(this._context)); } set { this._productCategoryRepository = value; } }

        #region Implementing IDiosposable...

        #region private dispose variable declaration...
        private bool disposed = false;
        #endregion

        /// <summary>
        /// Protected Virtual Dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {

                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public int Save()
        {
            try
            {
                return _context.SaveChanges();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion
    }
}
