﻿using Microsoft.EntityFrameworkCore;
using ShopBridge.Models;
using ShopBridge.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.Repositories.GenericRepository
{
    public class GenericRepository<TEntity> where TEntity : class
    {
        public ShopBridgeContext Context;
        public DbSet<TEntity> DbSet;
        private Models.EFModels.ShopBridgeContext context;

        public GenericRepository(ShopBridgeContext context)
        {
            this.Context = context;
            this.DbSet = context.Set<TEntity>();
            //this.Context.Database.SetCommandTimeout(300);
        }

       
    }
}
