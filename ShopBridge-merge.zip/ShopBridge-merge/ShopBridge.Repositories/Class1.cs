﻿using System;

namespace ShopBridge.Repositories
{
    public class Class1
    {
    }
}
