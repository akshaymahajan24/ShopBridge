﻿using Newtonsoft.Json.Linq;
using ShopBridge.Models.CommonModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.Services.Interfaces
{
    public interface IProductService
    {
        Task<APIResponse> GetAllProducts();
        Task<APIResponse> InsertProduct(JObject productDetails);
        APIResponse InsertProductCategory();
        Task<APIResponse> UpdateProduct(string productId, JObject productDetails);
        Task<APIResponse> DeleteProduct(string productId);
        Task<APIResponse> GetProductById(string productId);

    }
}
