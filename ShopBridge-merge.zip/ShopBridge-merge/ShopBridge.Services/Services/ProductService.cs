﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using ShopBridge.Models.CommonModels;
using ShopBridge.Models.EFModels;
using ShopBridge.Repositories.UnitOfWork;
using ShopBridge.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.Services.Services
{

    public class ProductService : IProductService
    {
        private readonly IUnitOfWork _unitOfWork;

        public ProductService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task<APIResponse> GetAllProducts()
        {
            APIResponse response = new APIResponse();
            var productList = await _unitOfWork.ProductRepository.DbSet.Include(x => x.ProductCategoryNavigation).Select(z => new ProductModel
            {
                Id = z.Id,
                ProductName = z.ProductName,
                Description = z.Description,
                Price = z.Price,
                ProductCategoryId = z.ProductCategory,
                ProductCategoryName = z.ProductCategoryNavigation.Category,
                ProductExpiryDate = z.ProductExpiryDate,
                UniqueIdentityNumber = z.UniqueIdentityNumber,
                Dimensions = z.Dimensions,
                CreatedBy = z.CreatedBy,
                IsActive = z.IsActive,
                ManufacturedBy = z.ManufacturedBy,
                CreatedDateTime = z.CreatedDateTime
            }).ToListAsync();
            response.Payload = productList;
            return response;
        }

        public async Task<APIResponse> InsertProduct(JObject productDetails)
        {
            APIResponse response = new APIResponse();
            Product product = new Product()
            {
                Id = Guid.NewGuid().ToString(),
                ProductName = GetPropertyValue(productDetails, "productname"),
                Description = GetPropertyValue(productDetails, "description"),
                ProductCategory = Convert.ToInt16(GetPropertyValue(productDetails, "productcategory")),
                Price = Convert.ToInt32(GetPropertyValue(productDetails, "price")),
                Dimensions = GetPropertyValue(productDetails, "dimensions"),
                UniqueIdentityNumber = GetPropertyValue(productDetails, "uniqueidentitynumber"),
                ProductExpiryDate = DateTime.UtcNow,
                ManufacturedBy = GetPropertyValue(productDetails, "manufacturedby"),
                CreatedBy = "1",
                CreatedDateTime = DateTime.UtcNow,
                IsActive = true

            };
            await _unitOfWork.ProductRepository.DbSet.AddAsync(product);
            _unitOfWork.Save();
            return response;
        }

        public APIResponse InsertProductCategory()
        {
            APIResponse response = new APIResponse();
            ProductCategory productCategory = new ProductCategory()
            {
                Category = "Watches",
                Description = "Good Watches",
                CreatedBy = "1",
                CreatedDateTime = DateTime.UtcNow,
                IsActive = true
            };
            _unitOfWork.ProductCategoryRepository.DbSet.Add(productCategory);
            _unitOfWork.Save();
            return response;
        }

        public string GetPropertyValue(JObject jObject, string property)
        {
            JProperty jProperty = jObject.Properties().Where(x => x.Name.ToLower() == property).FirstOrDefault();

            if (jProperty != null)
            {
                return !string.IsNullOrEmpty(jProperty.Value.ToString()) ? jProperty.Value.ToString() : null;
            }

            return null;
        }

        public async Task<APIResponse> UpdateProduct(string productId, JObject productDetails)
        {
            APIResponse response = new APIResponse();

            Product product = await _unitOfWork.ProductRepository.DbSet.Where(x => x.Id == productId).FirstOrDefaultAsync();
            if (product != null)
            {
                product.ProductName = GetPropertyValue(productDetails, "productname");
                product.Description = GetPropertyValue(productDetails, "description");
                product.ProductCategory = Convert.ToInt16(GetPropertyValue(productDetails, "productcategory"));
                product.Price = Convert.ToInt32(GetPropertyValue(productDetails, "price"));
                product.Dimensions = GetPropertyValue(productDetails, "dimensions");
                product.UniqueIdentityNumber = GetPropertyValue(productDetails, "uniqueidentitynumber");
                product.ProductExpiryDate = DateTime.UtcNow;
                product.ManufacturedBy = GetPropertyValue(productDetails, "manufacturedby");
                product.ModifiedBy = "1";
                product.ModifiedDateTime = DateTime.UtcNow;
                product.IsActive = true;
            }
            _unitOfWork.ProductRepository.DbSet.Update(product);
            _unitOfWork.Save();
            return response;
        }

        public async Task<APIResponse> DeleteProduct(string productId)
        {
            APIResponse response = new APIResponse();
            Product product = await _unitOfWork.ProductRepository.DbSet.Where(x => x.Id == productId).FirstOrDefaultAsync();
            if (product != null)
            {
                _unitOfWork.ProductRepository.DbSet.Remove(product);
                _unitOfWork.Save();
            }
            return response;
        }

        public async Task<APIResponse> GetProductById(string productId)
        {
            APIResponse response = new APIResponse();
            ProductModel productModel = await _unitOfWork.ProductRepository.DbSet.Where(x => x.Id == productId).Select(x => new ProductModel
            {
                Id = x.Id,
                ProductName = x.ProductName,
                Description = x.Description,
                Price = x.Price,
                ProductCategoryId = x.ProductCategory,
                ProductCategoryName = x.ProductCategoryNavigation.Category,
                ProductExpiryDate = x.ProductExpiryDate,
                UniqueIdentityNumber = x.UniqueIdentityNumber,
                Dimensions = x.Dimensions,
                CreatedBy = x.CreatedBy,
                IsActive = x.IsActive,
                ManufacturedBy = x.ManufacturedBy,
                CreatedDateTime = x.CreatedDateTime
            }).FirstOrDefaultAsync();

            response.Payload = productModel;
            return response;
        }


    }
}
