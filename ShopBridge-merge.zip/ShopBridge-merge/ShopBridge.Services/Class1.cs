﻿using System;

namespace ShopBridge.Services
{
    public class Class1
    {
    }
}
