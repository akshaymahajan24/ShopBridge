﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShopBridge.Models.CommonModels
{
    public class APIResponse
    {
        public bool Success { get { return Error == null ? true : (Error.Messages == null || !Error.Messages.Any() ? true : false); } }
        public Error Error { get; set; }
        public dynamic Payload { get; set; }
    }
    public class Error
    {
        public int? Code { get; set; }
        public List<string> Messages { get; set; }
    }
}
