﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.Models.CommonModels
{
    public class ProductModel
    {
        public string Id { get; set; }

        public string ProductName { get; set; }
        public string Description { get; set; }
        public int ProductCategoryId { get; set; }
        public string ProductCategoryName { get; set; }
        public int? Price { get; set; }

        public string Dimensions { get; set; }

        public string UniqueIdentityNumber { get; set; }

        public DateTime? ProductExpiryDate { get; set; }

        public string ManufacturedBy { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDateTime { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime? ModifiedDateTime { get; set; }

        public string DeletedBy { get; set; }

        public DateTime? DeletedDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
