﻿using System;

namespace ShopBridge.Models
{
    public class Class1
    {
    }
}
