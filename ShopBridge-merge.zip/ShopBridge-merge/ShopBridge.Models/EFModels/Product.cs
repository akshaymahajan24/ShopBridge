﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ShopBridge.Models.EFModels
{
    [Table("Product")]
    public partial class Product
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }
        [Required]
        [StringLength(100)]
        public string ProductName { get; set; }
        public string Description { get; set; }
        public int ProductCategory { get; set; }
        public int? Price { get; set; }
        [StringLength(50)]
        public string Dimensions { get; set; }
        [StringLength(50)]
        public string UniqueIdentityNumber { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ProductExpiryDate { get; set; }
        [StringLength(50)]
        public string ManufacturedBy { get; set; }
        [StringLength(50)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDateTime { get; set; }
        [StringLength(50)]
        public string ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDateTime { get; set; }
        [StringLength(50)]
        public string DeletedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? DeletedDateTime { get; set; }
        public bool? IsActive { get; set; }

        [ForeignKey(nameof(ProductCategory))]
        [InverseProperty("Products")]
        public virtual ProductCategory ProductCategoryNavigation { get; set; }
    }
}
