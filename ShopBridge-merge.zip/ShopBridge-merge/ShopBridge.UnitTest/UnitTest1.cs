﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Xunit;

namespace ShopBridge.UnitTest
{
   
    public class UnitTest1
    {
       // ProductController _productController;
        //[Fact]
        public void TestMethod1()
        {
        }
    }
}
